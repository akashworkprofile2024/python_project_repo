Paste into TWILIO CONFIGURATION in register_account.py
# Twilio configuration
# account_sid = 'AC7ceca5ee7068684f2f8598cba21961b5'
# auth_token = 'f4329ec4c320b7cb1129eacbf122a675'
# verify_sid = 'VAf6604de2676cc82a69e0c2b33da65ad6'
# client = Client(account_sid, auth_token)



Paste into OTP SCHEMA
# def send_otp(phone):
#     print(f"📤 Sending OTP to +91{phone}...")
#     try:
#         verification = client.verify.v2.services(verify_sid).verifications.create(
#             to=f'+91{phone}',
#             channel='sms'
#         )
#         return verification.sid
#     except Exception as e:
#         print(f"❌ Failed to send OTP: {e}")
#         return None

# def verify_otp(phone, otp_code):
#     try:
#         verification_check = client.verify.v2.services(verify_sid).verification_checks.create(
#             to=f'+91{phone}',
#             code=otp_code
#         )
#         return verification_check.status == 'approved'
#     except Exception as e:
#         print(f"❌ OTP verification failed: {e}")
#         return False


Paste into SEND OTP Section
# sid = send_otp(phone)
        # if not sid:
        #     print("⚠️ Cannot continue without OTP verification.")
        #     return

        # for attempt in range(3):
        #     otp_input = input("Enter the OTP sent to your phone: ")
        #     if verify_otp(phone, otp_input):
        #         print("✅ OTP Verified Successfully")
        #         break
        #     else:
        #         print("❌ Incorrect OTP. Try again.")
        # else:
        #     print("❌ OTP verification failed after 3 attempts.")
        #     return